//Author: Noah Frazier-Logue

$(document).ready(function(){
	$("ul").hide();
    $("#main0").click(function(){
        $("#original1").slideToggle('fast');
    });

    $("#main1").click(function(){
        $("#proofs1").slideToggle('fast');
    });
    $("#main2").click(function(){
        $("#proofs2").slideToggle('fast');
    });
    $("#main3").click(function(){
        $("#proofs3").slideToggle('fast');
    });

    $("#main4").click(function(){
        $("#proofs4").slideToggle('fast');
    });

    $("#main5").click(function(){
        $("#proofs5").slideToggle('fast');
    });

    $("#main6").click(function(){
        $("#spatials").slideToggle('fast');
    });

    $("#lemma_t2").click(function(){
        $("#lemmas2").slideToggle('fast');
    });
    $("#lemma_t4").click(function(){
        $("#lemmas4").slideToggle('fast');
    });
    $("#lemma_t5").click(function(){
        $("#lemmas5").slideToggle('fast');
    });
    $("#parts_t4").click(function(){
        $("#p4").slideToggle('fast');
    });
    $("#parts_t5").click(function(){
        $("#p5").slideToggle('fast');
    });


});
